package com.example.demo13.layer4;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo13.layer2.CurrentAccount;
import com.example.demo13.layer3.CurrentAccountRepository;
import com.example.demo13.myexceptions.CurrentAccountAlreadyExistsException;
import com.example.demo13.myexceptions.CurrentAccountNotFoundException;

@Service
public class CurrentAccountServiceImpl implements CurrentAccountService {

    @Autowired
    CurrentAccountRepository currRepo;
    

    @Override
    public void addCurrentAccountService(CurrentAccount obj) {
        // TODO Auto-generated method stub
        Optional<CurrentAccount> currObj =  currRepo.findById(obj.getAccountNumber());
        if(currObj.isPresent()) {
            throw new CurrentAccountAlreadyExistsException("This ID already exists : "+obj.getAccountNumber());
        }
        else {
            currRepo.save(obj);
            System.out.println("Account added...");
        }
    }

    @Override
    public void modifyCurrentAccountService(CurrentAccount obj) {
        Optional<CurrentAccount> currObj =  currRepo.findById(obj.getAccountNumber());
        if(currObj.isPresent()) {
            currRepo.save(obj); //if exists, it will modify
            System.out.println("Account modified...");

        }
        else {
            throw new CurrentAccountNotFoundException("This ID does not exists : "+obj.getAccountNumber());

        }
    }

    @Override
    public void removeCurrentAccountService(CurrentAccount obj) {
        // TODO Auto-generated method stub
        Optional<CurrentAccount> currObj =  currRepo.findById(obj.getAccountNumber());
        if(currObj.isPresent()) {
            currRepo.delete(obj);
            System.out.println("Account deleted...");

        }
        else {
            throw new CurrentAccountNotFoundException("This ID does not exists : "+obj.getAccountNumber());

        }
    }

    @Override
    public CurrentAccount findCurrentAccountService(int acno) {
        CurrentAccount currentAccount = null;
        Optional<CurrentAccount> currObj =  currRepo.findById(acno);
        if(currObj.isPresent()) {
            currentAccount = currObj.get();
          

        }
        else {
            throw new CurrentAccountNotFoundException("This ID does not exists : "+acno);

        }
        return currentAccount;
    }

    @Override
    public List<CurrentAccount> findAllCurrentAccountService() {

        List<CurrentAccount> currObjList =  (List<CurrentAccount>) currRepo.findAll();
        
        return currObjList;
    }
    
    
}
