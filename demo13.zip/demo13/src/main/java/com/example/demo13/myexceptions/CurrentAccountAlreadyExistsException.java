package com.example.demo13.myexceptions;

public class CurrentAccountAlreadyExistsException extends RuntimeException {
    
    public CurrentAccountAlreadyExistsException(String str) {
        super(str);
    }
}
