package com.example.demo13.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo13.layer2.CurrentAccount;
import com.example.demo13.layer4.CurrentAccountService;
import com.example.demo13.myexceptions.CurrentAccountAlreadyExistsException;
import com.example.demo13.myexceptions.CurrentAccountNotFoundException;

@RestController
@RequestMapping("/accounts")
public class CurrentAccountController { //localhost:8080/accounts/
    
    @Autowired
    CurrentAccountService currentAccountService;

    @GetMapping("/")
    public List<CurrentAccount> showAllCurrentAccounts() {
        //return "<h1> Welcome to Current Account DB management </h1>";
        return currentAccountService.findAllCurrentAccountService();

    }

    @GetMapping("/{num}") // localhost:8080/accounts/113
    public ResponseEntity showCurrentAccount(@PathVariable("num") int x) {
        
        try {
          CurrentAccount currObj =   currentAccountService.findCurrentAccountService(x);
          return ResponseEntity.status(HttpStatus.FOUND).body(currObj);

        }
        catch(CurrentAccountNotFoundException e) {
          return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());

        }
    }

    
    @PostMapping("/add") // localhost:8080/accounts/add
    public ResponseEntity addCurrentAccount(@RequestBody CurrentAccount currAccObj) {
        
        try {
          currentAccountService.addCurrentAccountService(currAccObj);
          return ResponseEntity.status(HttpStatus.CREATED).body("Account Created");
        }
        catch(CurrentAccountAlreadyExistsException e) {
          return ResponseEntity.status(HttpStatus.FOUND).body(e.getMessage());

        }
    }

    @PutMapping("/update") // localhost:8080/accounts/update
    public ResponseEntity updateCurrentAccount(@RequestBody CurrentAccount currAccObj) {
        
        try {
          currentAccountService.modifyCurrentAccountService(currAccObj);
          return ResponseEntity.status(HttpStatus.OK).body("Account Modified");
        }
        catch(CurrentAccountNotFoundException e) {
          return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());

        }
    }

    @DeleteMapping("/delete/{num}") // localhost:8080/accounts/delete
    public ResponseEntity deleteCurrentAccount(@PathVariable("num") int x) {
        
        try {
            CurrentAccount currentAccount = new CurrentAccount();
            currentAccount.setAccountNumber(x);
          currentAccountService.removeCurrentAccountService(currentAccount);
          return ResponseEntity.status(HttpStatus.OK).body("Account Removed");
        }
        catch(CurrentAccountNotFoundException e) {
          return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());

        }
    }

}
