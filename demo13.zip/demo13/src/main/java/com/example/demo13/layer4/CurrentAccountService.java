package com.example.demo13.layer4;

import org.springframework.stereotype.Service;

import com.example.demo13.layer2.CurrentAccount;
import java.util.*;

@Service
public interface CurrentAccountService {
    void addCurrentAccountService(CurrentAccount obj);
    void modifyCurrentAccountService(CurrentAccount obj);
    void removeCurrentAccountService(CurrentAccount obj);
    CurrentAccount findCurrentAccountService(int acno);
    List<CurrentAccount> findAllCurrentAccountService();
}
