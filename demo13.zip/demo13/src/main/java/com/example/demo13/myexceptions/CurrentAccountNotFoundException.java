package com.example.demo13.myexceptions;

public class CurrentAccountNotFoundException extends RuntimeException {

    public CurrentAccountNotFoundException(String string) {
        super(string);
    }

}