package com.example.demo13;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo13.layer2.CurrentAccount;
import com.example.demo13.layer3.CurrentAccountRepository;
import com.example.demo13.layer4.CurrentAccountService;
import com.example.demo13.myexceptions.CurrentAccountNotFoundException;


@SpringBootTest
class Demo13ApplicationTests {

	@Autowired
	CurrentAccountRepository currAccRepo;
	
	/*---- crud repo test cases */
	@Test
	public void insertCurrentAccountTest() {
		CurrentAccount currentAccount = new CurrentAccount();
		currentAccount.setAccountNumber(102);
		currentAccount.setAccountHolderName("Jane");
		currentAccount.setAccountBalance(60000);
		currAccRepo.save(currentAccount);
	}

	@Test
	void updateCurrentAccountTest() {
		Optional<CurrentAccount> currAccObj = currAccRepo.findById(102);
		if(currAccObj.isPresent()) {
			CurrentAccount actualCurrAccObject = currAccObj.get();
			System.out.println("--Current details --");
			System.out.println("acc no   : "+actualCurrAccObject.getAccountNumber());
			System.out.println("acc name : "+actualCurrAccObject.getAccountHolderName());
			System.out.println("acc bal  : "+actualCurrAccObject.getAccountBalance());		
		
			actualCurrAccObject.setAccountHolderName("JANET");
			actualCurrAccObject.setAccountBalance(65000);
			currAccRepo.save(actualCurrAccObject);
			System.out.println("Current account updated...");
		}
		else {
			throw new RuntimeException("Current account not found ...");
		}
	}
	@Test
	void deleteCurrentAccountTest() {
		Optional<CurrentAccount> currAccObj = currAccRepo.findById(102);
		if(currAccObj.isPresent()) {
			CurrentAccount actualCurrAccObject = currAccObj.get();
			System.out.println("--Current details --");
			System.out.println("acc no   : "+actualCurrAccObject.getAccountNumber());
			System.out.println("acc name : "+actualCurrAccObject.getAccountHolderName());
			System.out.println("acc bal  : "+actualCurrAccObject.getAccountBalance());		
		
		//	actualCurrAccObject.setAccountHolderName("JANET");
		//	actualCurrAccObject.setAccountBalance(65000);
			currAccRepo.delete(actualCurrAccObject);
			System.out.println("Current account deleted...");
		}
		else {
			throw new RuntimeException("Current account not found ...");
		}
	}
	@Test
	void selectCurrentAccountTest() {
		Optional<CurrentAccount> currAccObj = currAccRepo.findById(103);
		if(currAccObj.isPresent()) {
			CurrentAccount actualCurrAccObject = currAccObj.get();
			System.out.println("--Current details --");
			System.out.println("acc no   : "+actualCurrAccObject.getAccountNumber());
			System.out.println("acc name : "+actualCurrAccObject.getAccountHolderName());
			System.out.println("acc bal  : "+actualCurrAccObject.getAccountBalance());		
		
			currAccRepo.save(actualCurrAccObject);
			System.out.println("Current account found...");
		}
		else {
			throw new CurrentAccountNotFoundException("Current account not found ...");
			//throw new RuntimeException("Current account not found ...");
		}
	}

	
	@Test
	void selectAllCurrentAccountTest() {
		List<CurrentAccount> currList = (List<CurrentAccount>) currAccRepo.findAll();
		for (CurrentAccount currentAccount : currList) {
			System.out.println("acc no   : "+currentAccount.getAccountNumber());
			System.out.println("acc name : "+currentAccount.getAccountHolderName());
			System.out.println("acc bal  : "+currentAccount.getAccountBalance());		
			System.out.println("-------------");
		}
	}
	/*---------------- below are service test cases */


	@Autowired
	CurrentAccountService currService; //spring will bring the object of CurrentAccountServiceImpl's class

	@Test
	public void serviceTestingForAddingCurrentAccount() {
		CurrentAccount currentAccount = new CurrentAccount();
		currentAccount.setAccountNumber(103);
		currentAccount.setAccountHolderName("Ruchitha");
		currentAccount.setAccountBalance(52000);
		currService.addCurrentAccountService(currentAccount);
	}
	@Test
	public void serviceTestingForModifyingCurrentAccount() {
		CurrentAccount currentAccount = new CurrentAccount();
		currentAccount.setAccountNumber(103);
		currentAccount.setAccountHolderName("RUCHITHA B is happy");
		currentAccount.setAccountBalance(82000);
		currService.modifyCurrentAccountService(currentAccount);
	}

	@Test
	public void serviceTestingForDeletingCurrentAccount() {
		CurrentAccount currentAccount = new CurrentAccount();
		currentAccount.setAccountNumber(112);
		currService.removeCurrentAccountService(currentAccount);
	}

	@Test
	public void serviceTestingForFindingSingleCurrentAccount() {
		CurrentAccount currentAccount = currService.findCurrentAccountService(103);
		System.out.println("Account found...");
		System.out.println("acc no   : "+currentAccount.getAccountNumber());
		System.out.println("acc name : "+currentAccount.getAccountHolderName());
		System.out.println("acc bal  : "+currentAccount.getAccountBalance());		
	
	}

	@Test
	public void serviceTestingForFindingAllCurrentAccounts() {
		List<CurrentAccount> currentAccountList = currService.findAllCurrentAccountService();

		for (CurrentAccount currentAccount : currentAccountList) {
			System.out.println("acc no   : "+currentAccount.getAccountNumber());
			System.out.println("acc name : "+currentAccount.getAccountHolderName());
			System.out.println("acc bal  : "+currentAccount.getAccountBalance());		
		}
	}

}
