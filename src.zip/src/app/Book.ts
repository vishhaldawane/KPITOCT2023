export class Book {
    bookId!: number;
    bookName!: string;
    bookAuthor!: string;
    bookPrice!: number;
}